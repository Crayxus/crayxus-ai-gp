﻿# 简历快筛：一键升级到最新版（不经过程序里的「升级」按钮）
# 用法：把这个文件和「升级简历快筛.bat」放进 ResumeScreener.exe 所在的文件夹，双击 bat。
# 做的事：关掉正在跑的简历快筛 → 从 crayxus.com.au 下载最新代码（逐个校验 sha256）→ 换掉 app 文件夹 → 重新打开。
# 简历、打分记录、Key 都在 data 文件夹里，不动。
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$K = Split-Path -Parent $MyInvocation.MyCommand.Path
$exe = Join-Path $K 'ResumeScreener.exe'
$U = 'https://crayxus.com.au/rs-upd-7c41e9/'
function Say($t, $c = 'White') { Write-Host $t -ForegroundColor $c }
if (-not (Test-Path $exe)) { Say "这个文件要放在 ResumeScreener.exe 旁边（现在在 $K）" Red; Read-Host '按回车退出'; exit 1 }

Say '1/4 关掉正在跑的简历快筛…' Cyan
Get-CimInstance Win32_Process | Where-Object { $_.ExecutablePath -and ($_.ExecutablePath -ieq $exe) } | ForEach-Object { try { Stop-Process -Id $_.ProcessId -Force -ErrorAction Stop; Say "  关掉 $($_.ProcessId)" } catch {} }
Start-Sleep -Seconds 2

Say '2/4 下载最新版…' Cyan
$v = Invoke-RestMethod -Uri ($U + 'version.json?t=' + [DateTimeOffset]::Now.ToUnixTimeSeconds()) -UseBasicParsing
Say "  最新版本 v$($v.ver)：$($v.note)"
$new = Join-Path $K 'app.new'
if (Test-Path $new) { Remove-Item $new -Recurse -Force }
foreach ($p in $v.files.PSObject.Properties) {
  $dst = Join-Path $new ($p.Name -replace '/', '\')
  New-Item -ItemType Directory -Force (Split-Path -Parent $dst) | Out-Null
  Invoke-WebRequest -Uri ($U + $p.Name + '?v=' + $v.ver) -OutFile $dst -UseBasicParsing
  $h = (Get-FileHash $dst -Algorithm SHA256).Hash.ToLower()
  if ($h -ne $p.Value) { Say "  $($p.Name) 下载不完整，稍后再试" Red; Read-Host '按回车退出'; exit 1 }
  Say "  ✓ $($p.Name)"
}

Say '3/4 换上新版…' Cyan
$cur = Join-Path $K 'app'
$ok = $false
for ($i = 0; $i -lt 8 -and -not $ok; $i++) {
  try { if (Test-Path $cur) { Remove-Item $cur -Recurse -Force -ErrorAction Stop }; Rename-Item $new 'app' -ErrorAction Stop; $ok = $true }
  catch { Start-Sleep -Seconds 1 }
}
if (-not $ok) { Copy-Item (Join-Path $new '*') $cur -Recurse -Force; Remove-Item $new -Recurse -Force -ErrorAction SilentlyContinue }
Say "  已换成 v$($v.ver)" Green

Say '4/4 重新打开简历快筛…' Cyan
Start-Process -FilePath $exe -WorkingDirectory $K
Say "完成。网页左下角会显示「版本 v$($v.ver)」。这个窗口可以关了。" Green
Start-Sleep -Seconds 4
