@echo off
chcp 65001 >nul
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0升级简历快筛.ps1"
if errorlevel 1 pause
